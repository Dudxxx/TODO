# Vite + React + Tailwind

Projeto React com Javascript + Tailwind criado com Vite

[Configuração do Tailwind](https://tailwindcss.com/docs/guides/vite)
